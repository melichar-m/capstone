import pyautogui
import pygetwindow as gw
import random
import string
import time

# offset, width, user/password, window definitions
login_click_region_left_offset = 399
login_click_region_top_offset = 301
login_click_region_right_offset = 534
login_click_region_bottom_offset = 336

play_click_region_left_offset = 273
play_click_region_top_offset = 320
play_click_region_right_offset = 497
play_click_region_bottom_offset = 406

clear_button_left_offset = 137
clear_button_top_offset = 510
clear_button_right_offset = 184
clear_button_bottom_offset = 526

reset_option_left_offset = 117
reset_option_top_offset = 472
reset_option_right_offset = 194
reset_option_bottom_offset = 478

screenshot_region_offset_x = 113
screenshot_region_offset_y = 440
screenshot_width = 386
screenshot_height = 53
password = 'shittypassword'
title_substring = "RuneLite"
windows = gw.getWindowsWithTitle(title_substring)

if windows:
    runelite_window = windows[0]  # Assuming it's the first window that matches
else:
    print("RuneLite window not found")

login_top_left = (login_click_region_left_offset + runelite_window.left, login_click_region_top_offset + runelite_window.top)
login_bottom_right = (login_click_region_right_offset + runelite_window.left, login_click_region_bottom_offset + runelite_window.top)

play_top_left = (play_click_region_left_offset + runelite_window.left, play_click_region_top_offset + runelite_window.top)
play_bottom_right = (play_click_region_right_offset + runelite_window.left, play_click_region_bottom_offset + runelite_window.top)

clear_top_left = (clear_button_left_offset + runelite_window.left, clear_button_top_offset + runelite_window.top)
clear_bottom_right = (clear_button_right_offset + runelite_window.left, clear_button_bottom_offset + runelite_window.top)

reset_option_top_left = (reset_option_left_offset + runelite_window.left, reset_option_top_offset + runelite_window.top)
reset_option_bottom_right = (reset_option_right_offset + runelite_window.left, reset_option_bottom_offset + runelite_window.top)

screenshot_x = screenshot_region_offset_x + runelite_window.left
screenshot_y = screenshot_region_offset_y + runelite_window.top
screenshot_region = (screenshot_x,screenshot_y,screenshot_width,screenshot_height)

def sleep():
    time.sleep(random.uniform(0.5,1.5))

# String must be randomized in order to introduce different combinations of letters next to each other
# so the ML model doesn't learn association by neighboring characters
def random_string(i, max_length=80):
    # Generate lists of lowercase letters, uppercase letters, and special characters
    lowercase_letters = list(string.ascii_lowercase)
    uppercase_letters = [' ' + char for char in string.ascii_uppercase]  # Add space before uppercase
    special_characters = list(".,;'\"-!@*&%$()+=_-[]{}\\|/?<>:#$")

    # Combine all characters into a single list
    all_characters = lowercase_letters + uppercase_letters + special_characters

    # Shuffle the list to mix the characters
    random.shuffle(all_characters)

    # Join the characters to create the final string
    sequence = ''.join(all_characters)
    with open(f'C:\\Users\\Micha\\.runelite\\screenshots\\Pidgeot to\\google colab\\training v2\\{i}.txt', 'a') as file:
        file.write(sequence)
    return sequence

def human_typewrite(text, min_interval=0.01, max_interval=0.06):
    for char in text:
        pyautogui.write(char, interval=random.uniform(min_interval,max_interval))

# Type out the string as if humanO
def type_out_string(text, max_length=80):
    while text:
        sleep()
        pyautogui.press('enter')
        substring = text[:max_length]
        human_typewrite(substring)
        pyautogui.press('enter')
        sleep()
        text = text[max_length:]

# Click function for login button / play button purposes
def click_random_point_within_region(top_left, bottom_right):
    x_click = random.randint(top_left[0], bottom_right[0])
    y_click = random.randint(top_left[1], bottom_right[1])
    pyautogui.click(x_click, y_click)
    sleep()

def right_click_random_point_within_region(top_left, bottom_right):
    x_click = random.randint(top_left[0], bottom_right[0])
    y_click = random.randint(top_left[1], bottom_right[1])
    pyautogui.rightClick(x_click, y_click)
    sleep()

def reset_chat():
    right_click_random_point_within_region(clear_top_left, clear_bottom_right)
    click_random_point_within_region(reset_option_top_left, reset_option_bottom_right)

# Write username and password to throwaway account
def log_in(password):
    human_typewrite(password)
    pyautogui.press('enter')

# Screenshot the appropriate region and name it appropriately for our machine learning model
def take_screenshot(region, i):
    screenshot = pyautogui.screenshot(region=region)
    output_filename = f"{i}.png"
    screenshot.save(output_filename)

def main():
    # Focus on the Runelite window here if necessary
    print("Focus on the RuneLite window! \nStarting in 5...")
    time.sleep(1)
    print("4...")
    time.sleep(1)
    print("3...")
    time.sleep(1)
    print("2...")
    time.sleep(1)
    print("1...")
    
    # Log in to OSRS
    # Click "Existing User" button
    click_random_point_within_region(login_top_left, login_bottom_right)
    # Log in to the game
    log_in(password)
    # Wait for server
    time.sleep(10)
    # Click the Play button
    click_random_point_within_region(play_top_left, play_bottom_right)
    # Wait for server again
    time.sleep(5)
    
    
    for i in range(1000):
        type_out_string(random_string(i+1))
        take_screenshot(screenshot_region, i+1)



    

if __name__ == "__main__":
    main()
